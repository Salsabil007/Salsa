/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Community {
    private String department;
 private String institute;
 public Community(String a,String b)
 {
     department=a;
     institute=b;
 }
    public String get_Dept(){
        return department;
        
    }
    public String get_Inst()
    {
        return institute;
    }
    public void Show()
    {
        System.out.println(get_Dept());
        System.out.println(get_Inst());
    }

    
}
