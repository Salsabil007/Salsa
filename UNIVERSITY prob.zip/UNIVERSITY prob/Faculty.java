/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Faculty extends Employee{
    private int facultyCode;
    private String designation;
    private int joinYear;
    public Faculty(String a,String b,String c,String d,double e,double f,int g,String h,int i)
    {
        super(a,b,c,d,e,f);
        facultyCode=g;
        designation=h;
        joinYear=i;
    }
    public int get_facultyCode()
    {
        return facultyCode;
    }
    public String get_Desig()
    {
        return designation;
        
    }
    public int get_Year()
    {
        return joinYear;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_facultyCode());
        System.out.println(get_Desig());
        System.out.println(get_Year());
    }

    
}
