/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Employee extends Community{
    private String name;
 private String employeeID;
     private double esalary;
    private double increment;
    public Employee(String a,String b,String c,String d,double e,double f)
    {
        super(a,b);
        name=c;
        employeeID=d;
        esalary=e;
        increment=f;
        
    }
    public String get_Name()
    {
        return name;   
    }
    public String get_EmployeeId()
    {
        return employeeID;
    }
    public double get_Salary()
    {
        return esalary;
    }
    public double get_Increment()
    {
        return increment;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_Name());
        System.out.println(get_EmployeeId());
        System.out.println(get_Salary());
        System.out.println(get_Increment());
    }

    
}
