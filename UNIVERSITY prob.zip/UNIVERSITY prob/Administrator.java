/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Administrator extends Faculty{
   private String position;
   private double duration;
   public Administrator(String a,String b,String c,String d,double e,double f,int g,String h,int i, String j, double k)
   {
       super(a,b,c,d,e,f,g,h,i);
       position=j;
       duration=k;
   }
   public String get_Pos()
    {
        return position;
    }
    public double get_Duration()
    {
        return duration;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_Pos());
        System.out.println(get_Duration());
        
    }
 
}
