/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Student extends Community{
    private String name;
    private String studentID;
private String status;
public Student(String a,String b,String c,String d,String e)
{
    super(a,b);
    name=c;
    studentID=d;
    status=e;
}
    public String get_Name()
    {
        return name;
        
    }
    public String get_Status()
    {
        return status;
    }
    public String get_Id()
    {
        return studentID;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_Name());
        System.out.println(get_Id());
        System.out.println(get_Status());
    }
    


    
}
