/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Alumny extends Community{
    private String name;
    private int passYear;
    public Alumny(String a,String b,String c,int d)
    {
        super(a,b);
        name=c;
        passYear=d;
    }
    public String get_Name(){
        return name;
        
    }
    public int getPass_Year()
    {
        return passYear;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_Name());
        System.out.println(getPass_Year());
    }

    
}
