/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package university;

/**
 *
 * @author Susmi
 */
public class Teacher extends Faculty{
    private int noCourses;
    private double weeklyHour;
    public Teacher(String a,String b,String c,String d,double e,double f,int g,String h,int i,int j ,double k)
    {
        super(a,b,c,d,e,f,g,h,i);
         noCourses=j;   weeklyHour=k;
    }
    public int get_Nocourses()
    {
        return noCourses;
    }
    public double get_Hour()
    {
        return weeklyHour;
    }
    
    public void Show()
    {
        super.Show();
        System.out.println(get_Nocourses());
        System.out.println(get_Hour());
    }

    
}
