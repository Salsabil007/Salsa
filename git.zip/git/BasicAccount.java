/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication35;

/**
 *
 * @author Susmi
 */
public class BasicAccount extends BankAccount{
    private double checkAmount;
    private  int countChecks;
    private int checkbookNo;
    public BasicAccount(int a,String s1,String s2,String s3,double b,double b1,int a1,int a2)
    {
         super(a,s1,s2,s3,b);
         checkAmount=b1;
         countChecks=a1;
         checkbookNo=a2;
    }

    
}
