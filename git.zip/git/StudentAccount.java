/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication35;

/**
 *
 * @author Susmi
 */
public class StudentAccount extends Account{
    private String institute;
    private String status;
    public StudentAccount(int a,String s,String s1,String s3,String s4)
    {
        super(a,s,s1);
        institute=s3;
        status=s4;
    }
    public String get_ins()
    {
        return institute;
    }
    public String get_status()
    {
        return status;
    }


}
