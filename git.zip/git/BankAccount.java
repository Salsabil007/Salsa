/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication35;

/**
 *
 * @author Susmi
 */
public class BankAccount extends Account {
    private String bankName;
    private double balance;
    public BankAccount(int a,String s1,String s2,String s3,double b)
    {
        super(a,s1,s2);
        bankName=s3;
        balance=b;
    }
    public String get_bank()
    {
        return bankName;
    }
    public double get_balance()
    {
        return balance;
    }
    

    
}
