/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public abstract class Cube extends ThreeDShape{
    public Cube(String s,int a, int b, int c)
    {
        super(s,a,b,c);
    }
    public void area()
    {
        System.out.println(2*(getheight()*getlength()+getheight()*getwidth()+getwidth()*getlength()));
    }
    public void volume()
    {
        System.out.println(getheight()*getlength()*getwidth());
    }
    
}
