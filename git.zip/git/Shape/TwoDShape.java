/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public abstract class TwoDShape extends Shape {
    private int height;
    private int width;
    public TwoDShape(String s,int a, int b)
    {
        super(s);
        height=a; width=b;
    }
    int getheight()
    {
        return height;
    }
    int getwidth()
    {
        return width;
    }
    public abstract void area();
    
}
