/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public abstract class Sphere extends ThreeDShape{
    public Sphere(String s,int a, int b, int c)
    {
        super(s,a,b,c);
    }
    public void area()
    {
        System.out.println(4*3.14159*getheight()*getheight());
    }
    public void volume()
    {
        System.out.println((4/3)*3.14159*getheight()*getheight()*getheight());
    }
}
