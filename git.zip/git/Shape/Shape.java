/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public class Shape {
    String name;
    public Shape(String a)
    {
        name=a;
    }
    
 }
