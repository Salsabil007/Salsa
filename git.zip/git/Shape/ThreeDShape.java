/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public abstract class ThreeDShape extends Shape {
    private int height;
    private int width;
    private int length;
    ThreeDShape(String s,int a, int b, int c)
    {
        super(s);
        length=a; height=b; width=c;
    }
    int getlength()
    {
        return length;
    }
    int getheight()
    {
        return height;
    }
    int getwidth()
    {
        return width;
    }
    public abstract void area();
    public abstract void volume();
    
}
