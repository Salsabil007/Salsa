/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape;

/**
 *
 * @author mac
 */
public class Rectangle extends TwoDShape{
    public Rectangle(String s,int a, int b)
    {
        super(s,a,b);
    }

    /**
     *
     */
    @Override
    public void area()
    {
        System.out.println(getheight()*getwidth());
    }
    
}
