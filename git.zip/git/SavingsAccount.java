/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication35;

/**
 *
 * @author Susmi
 */
public class SavingsAccount extends BankAccount{
    private double depositAmount;
    private double withdrawalAmount;
    private int passbookNo;
    public int rate;
    public int fee;
    public int loweram;
    public SavingsAccount(int a,String s1,String s2,String s3,double b,double b1,double b2,int a1)
    {
        super(a,s1,s2,s3,b);
        depositAmount=b1;
        withdrawalAmount=b2;
        passbookNo=a1;
    }
    public double get_depam()
    {
        return depositAmount;
    }
    public double get_with()
    {
        return withdrawalAmount;
    }
    public void set_rate(int a)
    {
        rate=a;
    }
    public void set_with()
    {
        double withdrawalAmount=get_with()-(rate/100)*get_with();
    }
    public void set_fee(int a,int b)
    {
       fee=a;
       loweram=b;
    }
    

}
