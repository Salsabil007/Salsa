/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication35;

/**
 *
 * @author Susmi
 */
public class Account {
    private int accountNumber;
    private String holderName;
    private String holderType;
    /*public Account()
    {
        accountNumber=0;
    }*/
    public Account(int a,String s,String s1)
    {
        accountNumber=a;
        holderName=s;
        holderType=s;
    }
    public int get_account()
    {
        return accountNumber;
    }
    public String get_holderName()
    {
        return holderName;
    }
    public String get_holderType()
    {
        return holderType;
    }

    
}
